# solar-log

This is just a little project to parse a CSV file downloaded from EPEVER eLOG01 Record Accessory Adapter For EPEVER Tracer Series eTracer Series MPPT Solar Charge Controller.

Try it out! https://lewismoten.github.io/solar-log/

![](screenshot.png)
